

% calculates the relative frequency ratio 
% m/n 
function [relFreq] = CalcRelFreq(dataVect, minVal, maxVal) 
counter1 = 0; % Counter for rolling a 1 on dice  
counter2 = 0; % Counter for rolling a 2 on dice 
counter3 = 0; % Counter for rolling a 3 on dice 
counter4 = 0; % Counter for rolling a 4 on dice 
counter5 = 0; % Counter for rolling a 5 on dice 
counter6 = 0; % Counter for rolling a 6 on dice 
              % each counter represents their own m
spot1 = 0; % used to calculate m / n for each specific number rolled 
           %(n being the length of the given vector) 
           % each spot represents their own relative frequency to that
           % specific number roll
spot2 = 0; % relative frequency for 2 rolled 
spot3 = 0; % relative frequency for 3 rolled
spot4 = 0; % relative frequency for 4 rolled
spot5 = 0; % relative frequency for 5 rolled
spot6 = 0; % relative frequency for 6 rolled

for index = 1 : length(dataVect) % Goes through each iteration in a given 
                                 % vector 
    
    if dataVect(index) == 1 % checks the vector if there is a 1 value 
        
       counter1 = counter1 + 1; % Used to keep track of how many "1" values
                                % are in the data vector
       
       spot1 = counter1 / length(dataVect) ; % Used to calculate relative 
                                             % frequency of "1" (m/n)
       
    else if dataVect(index) == 2 % checks the vector if there is a 2 value 
        
       counter2 = counter2 + 1; % Used to keep track of how many "2" values
                                % are in the data vector
       
       spot2 = counter2 / length(dataVect) ;  % Used to calculate relative 
                                             % frequency of "2" (m/n)
       
        else if dataVect(index) == 3 % checks the vector if there is a 3 
                                     % value 
        
       counter3 = counter3 + 1; % Used to keep track of how many "3" values
                                % are in the data vector
       
       spot3 = counter3 / length(dataVect) ;  % Used to calculate relative 
                                             % frequency of "3" (m/n)
       
            else if dataVect(index) == 4 % checks the vector if there is a  
                                         % 4 value 
        
       counter4 = counter4 + 1; % Used to keep track of how many "4" values
                                % are in the data vector
       
       spot4 = counter4 / length(dataVect) ;  % Used to calculate relative 
                                             % frequency of "4" (m/n)
       
                else if dataVect(index) == 5 % checks the vector if there  
                                            % is a 5 value 
        
       counter5 = counter5 + 1; % Used to keep track of how many "5" values
                                % are in the data vector
       
       spot5 = counter5 / length(dataVect) ;  % Used to calculate relative 
                                             % frequency of "5" (m/n)
       
                    else if dataVect(index) == 6 % checks the vector if   
                                            % there is a 6 value         
        
       counter6 = counter6 + 1; % Used to keep track of how many "6" values
                                % are in the data vector
       
       spot6 = counter6 / length(dataVect) ; % Used to calculate relative 
                                             % frequency of "6" (m/n)
       
                           end
                       end
                   end
              end
        end
    end
      
end

relFreq = zeros((maxVal-minVal+1),1); % A vector of the stored relative 
                                      % frequencies in ascending integer 
                                      % order 

relFreq(1,:) = spot1; % Displays the first relative frequency 
relFreq(2,:) = spot2; % Displays the second relative frequency 
relFreq(3,:) = spot3; % Displays the third relative frequency 
relFreq(4,:) = spot4; % Displays the fourth relative frequency 
relFreq(5,:) = spot5; % Displays the fifth relative frequency 
relFreq(6,:) = spot6; % Displays the sixth relative frequency 
        
    end
