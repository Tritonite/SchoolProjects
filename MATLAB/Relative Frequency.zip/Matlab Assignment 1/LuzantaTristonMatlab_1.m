% Triston Luzanta 31Jan2020
load MatlabAssignment1; 

minVal = 1; 

maxVal = 6; 

die1sample = die1(1:100); % 100 samples of die1 

die2sample = die2(1:100); % 100 samples of die2 

% Plots of 100 and 1000 sameples of die1 and die2 
figure(1)
CalcRelFreq(die1sample, minVal, maxVal) % method for relative frequency
bar(CalcRelFreq(die2sample, minVal, maxVal)) % plots the relative freq
title('die1 100 samples')
xlabel('Integers')
ylabel('Relative Frequency')
hold on 
figure(2) 
CalcRelFreq(die2sample, minVal, maxVal)
bar(CalcRelFreq(die1sample, minVal, maxVal))
title('die2 100 samples')
xlabel('Integers')
ylabel('Relative Frequency')
hold on
figure(3)
CalcRelFreq(die1, minVal, maxVal)
bar(CalcRelFreq(die1, minVal, maxVal))
title('die1 1000 samples')
xlabel('Integers')
ylabel('Relative Frequency')
hold on 
figure(4)
CalcRelFreq(die2, minVal, maxVal)
bar(CalcRelFreq(die2, minVal, maxVal))
title('die2 1000 samples')
xlabel('Integers')
ylabel('Relative Frequency')
hold off
