/**
 * Class to represent an animal in a zoo. Animals have a species, name, weight,
 * and age.
 * 
 * @author Stephen Thung, references previous code from Dr.Fagg, Taner Davis
 * @version 2018-08-26
 */
/**
 * 
 * @author Triston Luzanta
 * @verion 2018-08-26
 */
public class Animal 
{
	/**
	 * The species of the animal
	 */
	private String species;

	/**
	 * The name of the animal
	 */
	private String name;

	/**
	 * The weight of the animal in pounds
	 */
	private double weight;

	/**
	 * The age of the animal in years
	 */
	private int age;

	/**
	 * Empty (Default) Constructor
	 * 
	 * Sets the weight to 0, age to 0, name to "noname", and species to "unknown"
	 */
	public Animal() 
	{
		weight = 0;
		age = 0;
		name = "noname";
		species = "unknown";

		// TODO: implement this method as described in the documentation.

	}

	/**
	 * Animal constructor setting all fields.
	 * 
	 * @param species
	 *            The animal species.
	 * @param name
	 *            The animal's name.
	 * @param weight
	 *            The animal's weight in pounds.
	 * @param age
	 *            The animal's age in year.
	 */
	public Animal(String species, String name, double weight, int age) 
	{
		this.species = species;
		this.name = name;
		this.weight = weight;
		this.age = age;
	}

	/**
	 * Return the name of the given Animal
	 * 
	 * @return String name of the animal object
	 */
	// TODO: create getters for name, weight, and age
	/**
	 * Return the species of the animal 
	 * 
	 * @return String name of animal species 
	 */
	public String getSpecies() 
	{
		return this.species;
	}

	/**
	 * Return the name of the animal
	 * 
	 * @return String name of the animal 
	 */

	public String getName()
{
		return this.name;
	}
/**
 * Return the weight of the animal 
 * 
 * @return double weight of the animal 
 */
	public double getWeight() 
	{
		return this.weight;
	}
/**
 * Return the age of the animal 
 * 
 * @return int age of the animal 
 */
	public int getAge() 
	{
		return this.age;
	}

	

	/**
	 * When the user needs to print out info about an animal, present the animal in
	 * order of name, weight, and selling price
	 * 
	 * @return The string representation of the Animal class, formatted as: "(name),
	 *         a (species). (weight, to one decimal place) pounds, (age) years
	 *         old.\n"
	 */
	public String toString() {
		// TODO: implement this method as described in the documentation.
		return String.format("%s, a %s. %.1f pounds, %s years old.\n", this.getName(), this.getSpecies(),
				this.getWeight(), this.getAge());

	}
}
