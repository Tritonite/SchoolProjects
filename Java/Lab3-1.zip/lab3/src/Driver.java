import java.io.IOException;

/**
 * Driver class that passes in the name of a csv file to Team to parse. The csv file is a list of players.
 * The data is then displayed.
 * @author Stephen
 * @version 2018-09-03
 */
/**
 * 
 * @author Triston 
 *@version 2018-09-08
 */
public class Driver
{
   public static void main(String[] args) throws IOException 
   {
	   Team team = new Team("Input.csv");
       
       // TODO: test your code here:
       team.writePlayers("TeamInfo.txt");
       team.writeStatistics("TeamStats.txt");
       
       // TODO: modify the Input.csv file to allow proper testing of playersFromState() and writePlayers(). Currently,
       //       Input.csv has only players from the same state. writePlayers() with two parameters should only write
       //       out information about a subset of players, not all players. This functionality needs to be tested.
       team.writePlayers("TeamHT.txt","Hawaii"); 
       System.out.println(team.playersFromState("Hawaii"));
   }
   
}