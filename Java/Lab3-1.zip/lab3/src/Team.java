import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Class that represents a Team of Football Players.
 * Stores a list of all the Players on the Team and computes some
 * statistics about the Team.
 * 
 * @author Stephen
 * @version 2018-09-03
 */
/**
 * 
 * @author Triston
 *@version 2018-09-08
 */
public class Team
{
    /**
     * The list of Players on the Team.
     * Don't worry about the "protected" for now; this is done to make tests easier.
     */
    protected ArrayList<Player> players = new ArrayList<Player>();
    
    /**
     * Constructor, takes in a csv file of Players and stores them in a list.
     * 
     * @param filename The name of the csv file containing a list of Players, one Player on each line. Assumes that the
     * csv file is at the top level of the project (not within any folders; at the same level as src and TODO.json).
     */
    public Team(String filename)
    {
    	// Attempt to read a csv file, catch an error if something goes wrong:
    	try
    	{
    		read(filename);
    	}
    	catch(IOException e)
    	{
    		System.out.println("Error reading from file!\n");
    		e.printStackTrace();
    	}
    }
    
    /**
     * Loads a list of players from a CSV file. Each line of the csv represents a single Player.
     * The first line of the csv denotes the order of the fields, you should not
     * construct a player from the first line.
     * 
     * @param filename The file to read from.
     * @throws IOException throws exception
     */
    public void read(String filename) throws IOException
    {
    	BufferedReader br = new BufferedReader(new FileReader(filename));
        String strg;  // String containing a line of data from the file.
        
        // TODO: Throw out header
        strg = br.readLine(); // inputs the first line 
        strg = br.readLine(); // inputs the next line 
        
        
        // TODO: Read in first row containing data, create and add a Player object to the arraylist.
        while ( /* TODO: select a terminating condition (no more lines of data in the file to read) */
        		 strg != null)
        {
            // TODO: Loop over the lines in the file, adding Player objects to the arraylist.
            // Remember: each line of the file after the header line is a String of comma separated value - the same
            // values that are needed by the Player constructor to create a player object.
        	Player firstPlayer = new Player(strg); // Creates new object firstPlayer
        	players.add(firstPlayer); // adds player 
        	strg = br.readLine(); // inputs the next line 
        	
        }
        
        br.close();
    }
    
    /**
     * Writes out information about the Players in the Team.
     * Specifically, loop through the list of players and add each toString to
     * the output (adding each new toString to the end of the previous, without
     * any additional formatting).
     * 
     * @param filename the file to write out to (should be a .txt file). Assumes that the file is at the top level
     * of the project (not within any folders; at the same level as src and TODO.json).
     * @throws IOException throws exception 
     */
    public void writePlayers(String filename) throws IOException
    {
    	// Set up the writer and string to output:
    	BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
    	String out = "";
    	
    	// TODO: build the output string.
    	for (int i = 0; i < players.size(); i++) {
    		out += players.get(i); 
    	}
    	
    	
    	// Write out the output string and close:
    	bw.write(out);
        bw.close();
    }
    
    /**
     * Writes out information about a subset of Players in the Team. Only writes out information about players from
     * a given home state.
     * Specifically, loop through the list of players and add each toString to
     * the output (adding each new toString to the end of the previous, without
     * any additional formatting).
     * 
     * @param filename the file to write out to (should be a .txt file). Assumes that the file is at the top level
     * of the project (not within any folders; at the same level as src and TODO.json).
     * @param homeState Players with a home state matching this input will have their information written out to
     * the file.
     * @throws IOException throws exception 
     */
    public void writePlayers(String filename, String homeState) throws IOException
    {
        // TODO: implement this. It should look very similar to writePlayers(String filename)
    	BufferedWriter bw = new BufferedWriter(new FileWriter(filename)); 
    	String out = ""; 
    	
    	for (int i = 0; i < players.size(); i++) {
    		if(players.get(i).getHomeState().equals(homeState)) {
    			out += players.get(i); 
    		}
    	}
    	bw.write(out); 
    	bw.close(); 
    }
    
    /**
     * Formats and writes out information about the statistics of a Team.
     * Specifically, write out information in the following format:
     * 
     * "Total Height: result of computeTotalHeight()\nLightest Player: name of Player returned by lightestPlayer()\n"
     * 
     * @param filename the file to write out to (should be a .txt file). Assumes that the file is at the top level
     * of the project (not within any folders; at the same level as src and TODO.json).
     * @throws IOException throws exception 
     */
    public void writeStatistics(String filename) throws IOException
    {
        // TODO: implement this. Look at writePlayers(String filename) for file output.
    	BufferedWriter bw = new BufferedWriter(new FileWriter(filename)); 
    	 
    	bw.write("Total Height: " + computeTotalHeight() + "\n" + "Lightest Player: " + lightestPlayer() + "\n" ); 
    	// inputs the formatted information in the file 
    	
    	bw.close(); 
    }
    
    /**
     * Gives the total height of the Team.
     * 
     * THIS FUNCTION IS GIVEN TO YOU AS A REFERENCE FOR LOOPING WITH PLAYERS. DO NOT CHANGE IT!
     * 
     * @return Sum of the heights of the Players in the Team.
     */
    public double computeTotalHeight()
    {
        double height = 0;
        for (int i = 0; i < players.size(); i++)
        {
        	height += players.get(i).getHeight();
        }
        return height;
    }
    
    /**
     * Calculates the subset of players which are from a given state.
     * 
     * @param state Players with a home state matching this input String "state" should be aggregated and returned.
     * @return An arraylist containing all players whose homeState is equal to the input variable "state".
     */
    public ArrayList<Player> playersFromState(String state)
    {
        // TODO: implement this. Reference getTotalHeight for ways to loop over the players arraylist.
    	ArrayList<Player> playerStates = new ArrayList<Player>(); 
    	// Sees if the player is from the same state if so the player is added
    	for (int i = 0; i < players.size(); i++) {
    		if (players.get(i).getHomeState().equals(state)) {
    			playerStates.add(players.get(i)); 
    		}
    	}
    return playerStates; 
    }
    
    
    /**
     * Determines if any players are from a city with a given name (ignores the states).
     * 
     * @param cityName the name to compare Player's cities to.
     * @return True if there is a player from a city with a name matching the input variable "cityName", else false.
     */
    public boolean anyPlayersFromCityName(String cityName)
    {
        // TODO: implement this. Reference getTotalHeight for ways to loop over the players arraylist.
    	for (int i = 0; i < players.size(); i++) {
    		// Sees if the player is from the same city name
    		if (players.get(i).getHomeCity().equalsIgnoreCase(cityName)){
    			return true; 
    		}
    	}
    	return false; 
    }
    
    /**
     * Finds the lightest Player (lowest weight variable).
     * 
     * @return A Player object that has the lowest weight variable out of all Players recorded.
     *         If there are no players on the team, return null.
     */
    public Player lightestPlayer()
    {
        // Set arbitrarily high; it is important that when doing value comparisons to find the lowest/highest value
        // that you make sure your starting value will always be outside the range of your data. Otherwise, your
        // starting value may incorrectly be calculated as the min/max:
        int lowestWeight = Integer.MAX_VALUE;

        // TODO: implement this. Reference getTotalHeight for ways to loop over the players arraylist. 
        Player lightestPlayer = null; 
        for( int i = 0; i < players.size(); i++) {
        	// Compares the weight
        	if(players.get(i).getWeight() < lowestWeight) {
        		lowestWeight = players.get(i).getWeight(); 
        		lightestPlayer = players.get(i); 
        	}
        }
        return lightestPlayer; 
    }
}
