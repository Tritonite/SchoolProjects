/**
 * A football player. The system keeps track of their name, homeCity/State, height, and weight.
 * 
 * @author Stephen
 * @version 2018-09-03
 */
/**
 * 
 * @author Triston
 *@version 2018-09-08
 */
public class Player
{


	/**
     * The city the player is from.
     */
    private String homeCity;
    
    /**
     * The state the player is from.
     */
    private String homeState;
    
    /**
     * The height of the player in feet.
     */
    private double height;
    
    /**
     * The weight of the player in pounds.
     */
    private int weight;
    
    /**
     * Constructor for Player. Takes in information on the Player as a comma delimited string, stores info on name,
     * height, weight, homeCity and homeState. Note that homeCity and homeState are not separated by a comma in the
     * input string, but by a foward slash.
     * 
     * @param strg Information about the Player in the format: "name,height,weight,home", where home is formatted as
     * "homeCity/homeState"
     */
    public Player(String strg)
    {
        // TODO: split up the information from the input string and store in the member variables.
    	
    	String[] info = strg.split(",");
    	this.name = info[0]; 
    	this.height = Double.parseDouble(info[1]); 
    	this.weight = Integer.parseInt(info[2]); 
    	String[] temp = info[3].split("/"); 
    	this.homeCity = temp[0]; 
    	this.homeState = temp[1]; 
    			
    	
    	
    
    	
    }
    
    /**
     * toString override. Gives all information about the Player.
     * 
     * @return All information about the Player formatted as (replacing parentheses with member variables):
     * "Name: (name), Height: (height, to 2 decimal places) ft, Weight: (weight) lbs, Home City: (homeCity), Home State: (homeState)\n"
     * 
     * e.g.
     * "Name: Kyler Murray, Height: 5.83 ft, Weight: 195 lbs, Home City: Allen, Home State: Texas\n"
     */
    @Override
    public String toString()
    {
    	return String.format("Name:%s, Height:%.2f ft, Weight:%s lbs, Home City: %s, Home State: %s", this.name, this.height, this.weight, this.homeCity, 
    			this.homeState + ("\n")); 
    }

    // TODO: generate getters.
/**
 * The name of the player.
 */
private String name;

/**Players name 
 * @return the name
 */
public String getName() {
	return name;
}

/**Players home city
 * @return the homeCity
 */
public String getHomeCity() {
	return homeCity;
}

/** Players home state
 * @return the homeState
 */
public String getHomeState() {
	return homeState;
}

/** Players height 
 * @return the height
 */
public double getHeight() {
	return height;
}

/** Players weight 
 * @return the weight
 */
public int getWeight() {
	return weight;
}
}
