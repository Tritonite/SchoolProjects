import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * 
 * @author Triston Luzanta
 * @version 2018-09-12
 */
public class MapData {

	// Observation array called sradData
	private Observation[] sradData;
	// Observation array called tairData
	private Observation[] tairData;
	// Observation array called ta9mData
	private Observation[] ta9mData;

	// the Observation array size
	private final int SIZE = 1000;
	// calculations null if it hits 10 or more
	private final int NUMBER_OF_MISSING_OBSERVATIONS = 10;

	// index for parsing the data
	private Integer numberOfStations = null;
	// starting index of stiddata
	private final int STID_POSITION = 0;
	// starting index of tairdata
	private final int TAIR_POSITION = 4;
	// starting index of sraddata
	private final int SRAD_POSITION = 13;
	// starting index of ta9mdata
	private final int TA9M_POSITION = 14;
	// string for averages of data
	private final String MESONET = "Mesonet";

	// String of the data input file
	private String directory;

	private Observation tairMin;

	private Observation tairMax;

	private Observation tairAverage;

	private Observation ta9mMin;

	private Observation ta9mMax;

	private Observation ta9mAverage;

	private Observation sradMin;

	private Observation sradMax;

	private Observation sradAverage;

	private Observation sradTotal;

	// what year it is in a number
	private int year;
	// what month it is in a number
	private int month;
	// what number day it is within the month
	private int day;
	// what hour it is within the day
	private int hour;
	// what minute it is within an hour
	private int minute;

	/**
	 * MapData constructor
	 * 
	 * @param year
	 *            year input
	 * @param month
	 *            month input
	 * @param day
	 *            day input
	 * @param hour
	 *            hour input
	 * @param minute
	 *            minute input
	 * @param directory
	 *            name of inputed directory
	 * @throws IOException
	 *             for weird input
	 */
	public MapData(int year, int month, int day, int hour, int minute, String directory) throws IOException {
		this.year = year;
		this.month = month;
		this.day = day;
		this.hour = hour;
		this.minute = minute;
		this.directory = directory;
	}

	/**
	 * Return the int of the year
	 * 
	 * @return the int of the year
	 */
	public int getYear() {
		return this.year;
	}

	/**
	 * Return the int of the month
	 * 
	 * @return
	 */
	public int getMonth() {
		return this.month;
	}

	/**
	 * Return the int of the day
	 * 
	 * @return int day of mapdata object
	 */
	public int getDay() {
		return this.day;
	}

	/**
	 * Return the int of the hour
	 * 
	 * @return int hour of mapdata object
	 */
	public int getHour() {
		return this.hour;
	}

	/**
	 * Return the int of the minute
	 * 
	 * @return int minute of mapdata object
	 */
	public int getMinute() {
		return this.minute;
	}

	/**
	 * Return the data of the inputed file
	 * 
	 * @return the string of the inputted file
	 */
	public String getDirectory() {
		return this.directory;
	}

	/**
	 * Creates and sets the filename * @return a string filename
	 */
	public String createFileName() {

		String mth = "";
		String dy = "";
		String hr = "";
		String min = "";
		// determines if the month,day,hour,minute needs a 0 pad or not
		if (this.month < 10) {
			mth = "0" + this.month;
		} else {
			mth = "" + this.month;
		}

		if (this.day < 10) {
			dy = "0" + this.day;
		} else {
			dy = "" + this.day;
		}
		if (this.hour < 10) {
			hr = "0" + this.hour;
		} else {
			hr = "" + this.hour;
			if (this.minute < 10) {
				min = "0" + this.minute;
			} else {
				min = "" + this.minute;
			}

		}
		return String.format("%d%s%s%s%s" + ".mdf", this.year, mth, dy, hr, min);
	}

	/**
	 * reads the filename and outputs the data line by line reads the tairData,
	 * sradData, and ta9mData and reads their statistics.
	 * 
	 * @throws IOException
	 */
	public void parseFile() throws IOException {
		// initializes the data sizes to 1000.
		this.sradData = new Observation[SIZE];
		this.ta9mData = new Observation[SIZE];
		this.tairData = new Observation[SIZE];

		// reads the filename
		BufferedReader br = new BufferedReader(new FileReader(this.directory + "/" + createFileName()));

		String[] split = null;

		// reads lines of data
		String strg = br.readLine();
		strg = br.readLine();
		strg = br.readLine();
		strg = br.readLine();

		numberOfStations = 0;
		// As long as strg doesnt = null the the data index will be incremented and will
		// be stored and read the next line.
		while (strg != null) {

			split = strg.trim().split("\\s+");

			this.tairData[numberOfStations] = new Observation(Double.parseDouble(split[TAIR_POSITION]),
					split[STID_POSITION]);
			this.sradData[numberOfStations] = new Observation(Double.parseDouble(split[SRAD_POSITION]),
					split[STID_POSITION]);
			this.ta9mData[numberOfStations] = new Observation(Double.parseDouble(split[TA9M_POSITION]),
					split[STID_POSITION]);
			numberOfStations++;

			strg = br.readLine();
		}

		// resize the arrays
		Observation[] temp1 = new Observation[numberOfStations];
		Observation[] temp2 = new Observation[numberOfStations];
		Observation[] temp3 = new Observation[numberOfStations];

		for (int j = 0; j < numberOfStations; j++) {
			temp1[j] = tairData[j];
			temp2[j] = sradData[j];
			temp3[j] = ta9mData[j];
		}
		// stores the temp variables to the data for validation
		tairData = temp1;
		sradData = temp2;
		ta9mData = temp3;
		// calls the methods to parse the statistics
		calculateAirTemperatureStatistics();
		calculateTa9mTemperatureStatistics();
		calculateSolarRadiationStatistics();

		br.close();
	}

	/**
	 * Get the sradAverage data
	 * 
	 * @return the stored sradAverage observation
	 */
	public Observation getSradAverage() {
		return this.sradAverage;
	}

	/**
	 * Get the sradMax data
	 * 
	 * @return the stored sradMax observation
	 */
	public Observation getSradMax() {
		return this.sradMax;
	}

	/**
	 * Get the sradMin data
	 * 
	 * @return the stored sradMin observation
	 */
	public Observation getSradMin() {
		return this.sradMin;
	}

	/**
	 * Get the sradTotal data
	 * 
	 * @return the stored sradTotal observation
	 */
	public Observation getSradTotal() {
		return this.sradTotal;
	}

	/**
	 * Get the ta9mAverage data
	 * 
	 * @return the stored ta9mAverage observation
	 */
	public Observation getTa9mAverage() {
		return this.ta9mAverage;
	}

	/**
	 * Get the ta9mMax data
	 * 
	 * @return the stored ta9mMax observation
	 */
	public Observation getTa9mMax() {
		return this.ta9mMax;
	}

	/**
	 * Get the ta9mMin data
	 * 
	 * @return the stored ta9mMin Observation
	 */
	public Observation getTa9mMin() {
		return this.ta9mMin;
	}

	/**
	 * Get the tairAverage data
	 * 
	 * @return the stored tairAverage Observation
	 */
	public Observation getTairAverage() {
		return this.tairAverage;
	}

	/**
	 * Get the tairMax data
	 * 
	 * @return the stored tairMax Observation
	 */
	public Observation getTairMax() {
		return this.tairMax;
	}

	/**
	 * Get the tairMin data
	 * 
	 * @return the stored tairMax Observation
	 */
	public Observation getTairMin() {
		return this.tairMin;
	}

	/**
	 * Formats the data
	 * 
	 * @return a string of the outputted format
	 */
	public String toString() {
		String map = "========================================================= \n";
		String one = String.format("=== %d-%02d-%02d %02d:%02d === \n", this.year, this.month, this.day, this.hour,
				this.minute);
		String two = String.format("Maximum Air Temperature[1.5m] = %3.1f C at %s \n", this.tairMax.getValue(),
				this.tairMax.getStid());
		String three = String.format("Minimum Air Temperature[1.5m] = %3.1f C at %s \n", this.tairMin.getValue(),
				this.tairMin.getStid());
		String four = String.format("Average Air Temperature[1.5m] = %3.1f C at %s \n", this.tairAverage.getValue(),
				this.tairAverage.getStid());
		String five = String.format("Maximum Air Temperature[9.0m] = %3.1f C at %s \n", this.ta9mMax.getValue(),
				this.ta9mMax.getStid());
		String six = String.format("Minimum Air Temperature[9.0m] = %3.1f C at %s \n", this.ta9mMin.getValue(),
				this.ta9mMin.getStid());
		String seven = String.format("Average Air Temperature[9.0m] = %3.1f C at %s \n", this.ta9mAverage.getValue(),
				this.ta9mAverage.getStid());
		String eight = String.format("Maximum Solar Radiation[1.5m] = %3.1f W/m^2 at %s \n", this.sradMax.getValue(),
				this.sradMax.getStid());
		String nine = String.format("Minimum Solar Radiation[1.5m] = %3.1f W/m^2 at %s \n", this.sradMin.getValue(),
				this.sradMin.getStid());
		String ten = String.format("Average Solar Radiation[1.5m] = %3.1f W/m^2 at %s \n", this.sradAverage.getValue(),
				this.sradAverage.getStid());

		String output = (map + one + map + two + three + four + map + map + five + six + seven + map + map + eight
				+ nine + ten + map);
		return output;
	}

	/**
	 * Calculates the tairMax,tairMin,tairAverage datas.
	 * 
	 */
	private void calculateAirTemperatureStatistics() {
		double temp = -Double.MAX_VALUE; // compares the value to the negative maximum value holder
		int count10 = 0;
		// calculates tairData Max
		for (int i = 0; i < this.tairData.length; i++) {
			// checks if data is valid
			if (this.tairData[i].isValid() == true) {
				// checks if data is greater than temp if so temp reassigns as data
				if (this.tairData[i].getValue() > temp) {
					temp = this.tairData[i].getValue();
					count10 = i;
				}
			}
		}
		// sets the tairMax data to a new observation object storing temp.
		this.tairMax = new Observation(temp, tairData[count10].getStid());

		int count2 = 0;
		double temp2 = Double.MAX_VALUE;
		// Calculates tairMin data
		for (int i = 0; i < tairData.length; i++) {
			// checks if data is valid
			if (this.tairData[i].isValid() == true) {
				if (this.tairData[i].getValue() < temp2) {
					temp2 = this.tairData[i].getValue();
					count2 = i;

				}

			}
		}

		this.tairMin = new Observation(temp2, tairData[count2].getStid());

		int loss = 0;
		double average = 0;
		double total = 0;
		int count3 = 0;
		// Calculates tairAverage data
		for (int i = 0; i < tairData.length; i++) {
			// checks if data is valid
			if (this.tairData[i].isValid() == true) {
				total += tairData[i].getValue();
				count3++;
			}
			// prints out an error message if the number of missing observations exceeds 10.
			else {
				loss++;
				if (loss > NUMBER_OF_MISSING_OBSERVATIONS) {
					System.out.println("Error");
				}
			}
		}
		// Calculates the average
		average = total / count3;
		// sets the tairAverage to an Observation object with average stored.
		this.tairAverage = new Observation(average, MESONET);

	}

	/**
	 * Calculates the ta9mData's Min,Max, and average.
	 */
	private void calculateTa9mTemperatureStatistics() {
		double temp = -Double.MAX_VALUE;
		int count4 = 0;
		// Calculates ta9mMax data
		for (int i = 0; i < this.ta9mData.length; i++) {
			// checks if data is valid
			if (this.ta9mData[i].isValid() == true) {
				if (this.ta9mData[i].getValue() > temp) {
					temp = this.ta9mData[i].getValue();
					count4 = i;
				}
			}
		}
		this.ta9mMax = new Observation(temp, ta9mData[count4].getStid());

		double temp2 = Double.MAX_VALUE;
		int count5 = 0;
		// Calculates ta9mMinData
		for (int i = 0; i < this.ta9mData.length; i++) {
			// checks if data is valid
			if (this.ta9mData[i].isValid() == true) {
				if (this.ta9mData[i].getValue() < temp2) {

					temp2 = this.ta9mData[i].getValue();
					count5 = i;
				}
			}
		}
		this.ta9mMin = new Observation(temp2, ta9mData[count5].getStid());

		int loss = 0;
		double average = 0;
		double total = 0;
		int count = 0;
		// Calculates ta9mAverage Data
		for (int i = 0; i < ta9mData.length; i++) {
			// checks if data is valid
			if (this.ta9mData[i].isValid() == true) {
				count++;
				total += ta9mData[i].getValue();
			} else {
				loss++;
				if (loss > NUMBER_OF_MISSING_OBSERVATIONS) {
					System.out.println("Error");
				}

			}
		}
		average = total / count;
		this.ta9mAverage = new Observation(average, MESONET);

	}

	/**
	 * Calculates sradData's Min,Max,Average,and Total.
	 */
	private void calculateSolarRadiationStatistics() {

		double temp = -Double.MAX_VALUE;
		int count6 = 0;
		// Calculates sradMax Data
		for (int i = 0; i < this.sradData.length; i++) {
			// checks if data is valid
			if (this.sradData[i].isValid() == true) {
				if (this.sradData[i].getValue() > temp) {
					temp = this.sradData[i].getValue();
					count6 = i;
				}
			}
		}
		this.sradMax = new Observation(temp, sradData[count6].getStid());

		double temp3 = Double.MAX_VALUE;
		int count7 = 0;
		// Calculates sradMin Data
		for (int i = 0; i < this.sradData.length; i++) {
			// checks if data is valid
			if (this.sradData[i].isValid() == true) {
				if (this.sradData[i].getValue() < temp3) {
					temp3 = this.sradData[i].getValue();
					count7 = i;
				}
			}
		}
		this.sradMin = new Observation(temp3, sradData[count7].getStid());

		double total = 0;
		int count8 = 0;
		int loss = 0;
		// Calculates sradTotal Data
		for (int i = 0; i < this.sradData.length; i++) {
			// checks if data is valid
			if (this.sradData[i].isValid()) {
				total += this.sradData[i].getValue();
				count8 = i;
			} else {
				loss++;
				if (loss > NUMBER_OF_MISSING_OBSERVATIONS) {
					System.out.println("Error");
				}
			}
		}
		this.sradTotal = new Observation(total, MESONET);

		double average = 0;
		int count = 0;
		double total2 = 0;
		// Calculates sradAverage data
		for (int i = 0; i < sradData.length; i++) {
			// checks if data is valid
			if (this.sradData[i].isValid() == true) {
				total2 += this.sradData[i].getValue();
				count++;
			}
		}
		average = total2 / count;
		this.sradAverage = new Observation(average, MESONET);

	}

}
