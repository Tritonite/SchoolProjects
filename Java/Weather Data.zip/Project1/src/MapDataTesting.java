
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Test;

/**
 * 
 * @author Triston Luzanta
 *@version 2018-09-12
 */

public class MapDataTesting {
	
/**
 * Testing getYear method  
 * @throws IOException 
 */
	@Test 
	public void getYearTest() throws IOException 
	{
		int test = 1; 
		MapData t = new MapData(test, 1, 2, 3, 4, "test");  
		//Expected 
		int expect = 1; 
		//Actual 
		int actual = t.getYear(); 
		assertEquals(expect, actual);
		 
	}
	 
	/**
	 * Testing getMonth method
	 * @throws IOException 
	 */
	@Test
	public void getMonthTest() throws IOException 
	{
		int test = 2; 
		MapData test1 = new MapData(1, test, 2,3,4,"test"); 
		//Expected
		int expect = 2; 
		//Actual 
		int actual = test1.getMonth(); 
		assertEquals(expect, actual); 
		
		
		
	}
	/**
	 *  Testing getDay method
	 * @throws IOException 
	 */
	@Test
	public void getDayTest() throws IOException 
	{
		int test = 3; 
		MapData test2 = new MapData(1,2,test,3,4,"test"); 
		//Expected 
		int expect = 3; 
		//Actual
		int actual = test2.getDay(); 
		assertEquals(expect, actual);
	
	}
	/**
	 * Testing getHour method 
	 * @throws IOException 
	 */
	@Test
	public void getHourTest() throws IOException
	{
		int test = 4; 
		MapData test3 = new MapData(1,2,3,test,4,"test"); 
		//Expected 
		int expect = 4;  
		//Actual 
		int actual = test3.getHour(); 
		assertEquals(expect, actual);
	
	}
	/**
	 * Testing getMinute method 
	 * @throws IOException 
	 */
	@Test
	public void getMinuteTest() throws IOException 
	{
		int test = 5; 
		MapData test4 = new MapData(1,2,3,4,test,"test"); 
		//Expected
		int expect = 5; 
		//Actual 
		int actual = test4.getMinute(); 
		assertEquals(expect, actual);
		
		
	}
	/**
	 * Testing getDirectory method 
	 * @throws IOException 
	 */
	@Test
	public void getDirectoryTest() throws IOException
	{
		String test = "testing"; 
		MapData test5 = new MapData(1,2,3,4,5,test); 
		//Expected 
		String expect = "testing"; 
		//Actual 
		String actual = test5.getDirectory(); 
		assertEquals(expect, actual);
		
	}
	/**
	 * Testing createFileName method
	 * @throws IOException 
	 */
	@Test
	public void testCreateFileName() throws IOException 
	{
		MapData filetest = new MapData(2018,8,30,17,45,"data");   
		assertEquals("201808301745.mdf", filetest.createFileName());
		 
	}
	/**
	 * Testing parseFile method 
	 * @throws IOException 
	 */
	@Test
	public void testParseFile() throws IOException 
	{
		MapData parseTest = new MapData(2018,8,30,17,45,"data"); 
		String test = parseTest.createFileName(); 
		 parseTest.parseFile();
		 
		 assertEquals(968.0, parseTest.getSradMax().getValue(),0.01); 
		 assertEquals(163.0, parseTest.getSradMin().getValue(),0.01); 
		 assertEquals(828.1, parseTest.getSradAverage().getValue(),0.1); 
		 assertEquals(36.5, parseTest.getTairMax().getValue(),0.1); 
		 assertEquals(20.8, parseTest.getTairMin().getValue(),0.1); 
		 assertEquals(32.4, parseTest.getTairAverage().getValue(),0.1); 
		 assertEquals(34.9, parseTest.getTa9mMax().getValue(),0.1); 
		 assertEquals(20.7, parseTest.getTa9mMin().getValue(),0.1); 
		 assertEquals(31.6, parseTest.getTa9mAverage().getValue(),0.1); 
		  
		}
	
	@Test 
	public void testToString() throws IOException
	{ 
		
		MapData test = new MapData(2018,8,30,17,45,"data"); 
		test.parseFile(); 
		// The date
        int year = 2018;
        int month = 8;
        int day = 30;
        int hour = 17;
        int minute = 45; 

        // Expected values
        double TairMax = 36.5;
        double TairMin = 20.8;
        double TairAvg = 32.4;
        double Ta9mMax = 34.9;
        double Ta9mMin = 20.7;
        double Ta9mAvg = 31.6;
        double sradMax = 968.0;
        double sradMin = 163.0;
        double sradAvg = 828.1; 
 
        // STID Names
        String Hook = "HOOK";
        String Miam = "MIAM";
        String Mesonet = "Mesonet"; 
        String Slap = "SLAP";
String expected = String.format("========================================================= \n" + 
                          "=== %d-%02d-%02d %02d:%02d === \n", year, month, day, hour, minute) +
                          String.format( "========================================================= \n" +
                          "Maximum Air Temperature[1.5m] = %3.1f C at %s \n" +  
                          "Minimum Air Temperature[1.5m] = %3.1f C at %s \n" +
                          "Average Air Temperature[1.5m] = %3.1f C at %s \n", TairMax, Hook, TairMin, Miam, TairAvg, Mesonet)
                          + String.format( "========================================================= \n" +
                          "========================================================= \n" +
                          "Maximum Air Temperature[9.0m] = %3.1f C at %s \n" +
                          "Minimum Air Temperature[9.0m] = %3.1f C at %s \n" +
                          "Average Air Temperature[9.0m] = %3.1f C at %s \n" +
                          "========================================================= \n" +
                          "========================================================= \n", Ta9mMax, Hook, Ta9mMin, Miam, Ta9mAvg, Mesonet) 
                          + String.format("Maximum Solar Radiation[1.5m] = %3.1f W/m^2 at %s \n" +
                          "Minimum Solar Radiation[1.5m] = %3.1f W/m^2 at %s \n" +
                          "Average Solar Radiation[1.5m] = %3.1f W/m^2 at %s \n" + 
                          "========================================================= \n", sradMax, Slap, sradMin, Miam, sradAvg, Mesonet);
	String actual = test.toString(); 	
		assertEquals(expected, actual) ;  
	     
	}  
	
	
}


