import org.junit.Assert;
import org.junit.Test;
/**
 * 
 * @author Triston Luzanta
 * @version 2018-09-15
 */


public class PlayerTest {

	@Test
	public void playerTest() {
		String strg = "1,2,3,4/5"; 
		Player test = new Player(strg); 
		Assert.assertEquals("Name", "1", test.getName());
		Assert.assertEquals("Height", 2.0, test.getHeight(),0.01);
		Assert.assertEquals("Weight", 3, test.getWeight());
		Assert.assertEquals("HomeCity", "4", test.getHomeCity());
		Assert.assertEquals("HomeState", "5",test.getHomeState()); 
		
	 
		     
		 
		 
	} 
	
	@Test
	public void toStringTest() {
		String test = "1,2.0,3,4/5"; 
		Player player = new Player(test);
		String testing = (("Name: 1, Height: 2.00 ft, Weight: 3 lbs, Home City: 4, Home State: 5\n")); 
				             
		String act = player.toString();  
		Assert.assertEquals(testing,act);   
	}

}
