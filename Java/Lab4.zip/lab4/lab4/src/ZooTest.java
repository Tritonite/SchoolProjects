import org.junit.Assert;
import org.junit.Test;


/**
 * Testing class for the Zoo class
 * 
 * @author Stephen Thung
 * @version 2018-09-10
 */
/**
 * 
 * @author modified Triston Luzanta
 * @version 2018-09-15
 */
public class ZooTest 
{
    /**
     * Test the empty constructor
     */
    @Test 
    public void emptyConstructorTest()  
    {
        //Use the default constructor
        Zoo zoo = new Zoo();

        Assert.assertEquals(0, zoo.getTotalWeight(), 0.01);
        Assert.assertEquals(0, zoo.getAverageAge());
        Assert.assertEquals(0, zoo.getSize());
    }
  
    /**
     * Test adding an product to the zoo
     */
    @Test
    public void addAnimalTest() 
    {
    	
        //Use the default constructor 
        Zoo zoo = new Zoo();
 
        // TODO: Create animals to add to the zoo
        Animal dog = new Animal ("Dog","Matilda", 56.0, 6); 
        Animal rabbit = new Animal ("Rabbit", "Peebo", 13.0, 2); 
        // TODO: Add the animals to the Inventory;
        zoo.addAnimal(dog);
        zoo.addAnimal(rabbit); 
        	
         // TODO: test that the number of animals added (currentIndex) is updated correctly.
          /*
         * The animals should be in the array and in the
         * order added above. 
         */
        Assert.assertEquals(dog, zoo.getAnimals()[0]); 
        Assert.assertEquals(rabbit, zoo.getAnimals()[1]);
    }

    /**
     * DUE TO HIGHER COMPLEXITY, THIS TEST IS GIVEN TO YOU. YOU SHOULD NOT MODIFY IT.
     * 
     * Test the zoo's ability to expand
     * and meet the need of having adequate space
     * to add more animals when needed.
     */
    @Test
    public void extendArrayAndGetSizeTest() 
    {
        //Use the default constructor
        Zoo zoo = new Zoo();

        /*
         * Attempt to force the animal array to expand.
         * Fails when the array doesn't realize it should
         * get bigger and tries to add an product or
         * when it tries to insert an product in a
         * non-existent position in the array,
         */
        try
        {
            for (int i = 0 ; i < 10; i++)
            {
                zoo.addAnimal(new Animal()); //Add empty Products to array
            }
        }
        catch (NullPointerException e) //Catch any point the array goes wrong
        {
            Assert.fail("The Product array attempted to access a non-existent "
                    + "position in the product array.");
        }

        //Test the size of the new array
        Assert.assertEquals("Not all animals added as expected.", 10, zoo.getSize());
        Assert.assertEquals("animals array not expanded correctly.", 11, zoo.getAnimals().length);
    }

    /**
     * Tests the total weight calculation.
     */
    @Test
    public void getTotalWeightTest()
    {
        // TODO: set up zoo
    	Zoo zoo = new Zoo(); 

        // TODO: Create at least 3 animals to add to the zoo
    	Animal bear = new Animal("Bear", "Teddy", 150.0, 3); 
    	Animal frog = new Animal("Frog", "Tsu", 100.0, 4); 
    	Animal panda = new Animal("Frog", "Atticus", 150.0, 5); 

        // TODO: add the animals to the Inventory
    	zoo.addAnimal(bear);
    	zoo.addAnimal(frog);
    	zoo.addAnimal(panda);
        
        // TODO: test that sum of animal weights matches function return
    	Assert.assertEquals(400.0, zoo.getTotalWeight(),0.01);
    }
    

    /**
     * Tests the average age calculation.
     */
    @Test
    public void getAverageAgeTest()
    {
        // TODO: finish the test. You should use at least 3 animals.
    	Zoo zoo = new Zoo(); 
    	
    	Animal tiger = new Animal("Tiger", "Triton", 300.0, 5); 
    	Animal bird = new Animal ("Toucan", "Sam", 100.0, 4); 
    	Animal cheetah = new Animal("Cheetah", "Joe", 200.0, 6); 
    	
    	zoo.addAnimal(tiger);
    	zoo.addAnimal(bird);
    	zoo.addAnimal(cheetah);
    	
    	Assert.assertEquals(5, zoo.getAverageAge());
    	
    }

    /**
     * Tests the sum age for animals with a given name calculation.
     */
    @Test
    public void totalAgeWithNameTest()
    {
        // TODO: finish the test. You should use at least 3 animals.
    	Zoo zoo = new Zoo(); 
    	
    	Animal dog = new Animal("Bulldog", "Matilda", 56.0,6); 
    	Animal rabbit = new Animal("Dwarf", "Peebo", 15.0,2); 
    	Animal wolf = new Animal("Gray", "Peebo", 120.0, 2 ); 
    	
    	zoo.addAnimal(dog); 
    	zoo.addAnimal(rabbit);
    	zoo.addAnimal(wolf);
    	
    	Assert.assertEquals(4, zoo.totalAgeWithName("Peebo")); 
    }

    /**
     * Tests the number of animals for a species calculation
     */
    @Test
    public void numberAnimalsOfSpeciesTest()
    {
        // TODO: finish the test. You should use at least 3 animals.
    	Zoo zoo = new Zoo(); 
    	
    	Animal dog = new Animal("Wolf", "Duke", 60.0,4); 
    	Animal rabbit = new Animal("Wolf", "Nuke", 70.0,5); 
    	Animal wolf = new Animal("Wolf", "Luke", 80.0, 6); 
    	 
    	zoo.addAnimal(dog); 
    	zoo.addAnimal(rabbit);
    	zoo.addAnimal(wolf); 
    	
    	Assert.assertEquals(3, zoo.numberAnimalsOfSpecies("Wolf"));
    }

    /**
     * Test the string representation of the Inventory 
     */
    @Test
    public void zooToStringTest()
    {
        // TODO: set up the zoo
    	Zoo zoo = new Zoo(); 

        // TODO: Create animals to add to the zoo
    	Animal dog = new Animal("BullDog", "Duke", 60.0,4); 
    	Animal rabbit = new Animal("Rabbit", "Nuke", 70.0,5); 
    	Animal wolf = new Animal("Wolf", "Luke", 80.0, 6); 

        // TODO: Add the animals to the Inventory
    	zoo.addAnimal(dog); 
    	zoo.addAnimal(rabbit);
    	zoo.addAnimal(wolf);
        // TODO: Create the expected string
    	String expected = "The following animals currently reside in the zoo: \n"
    			+ "Duke, a BullDog. 60.0 pounds, 4 years old\n"
    			+ "Nuke, a Rabbit. 70.0 pounds, 5 years old\n"  
    			+ "Luke, a Wolf. 80.0 pounds, 6 years old\n"; 
        // TODO: Test the string output produced by toString
    	String actual = zoo.toString(); 
    	  
    	Assert.assertEquals(expected, actual);   
    }  
}